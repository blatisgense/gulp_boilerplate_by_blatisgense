# Gulp_bundle_blatisgense
My dev.  Gulp bundle.
# Made with most simple syntax for beginners.
#
#
#
# For styles used:
- Autoprefixer with browserList to make CSS crossbrowser and comparable with old versions. 
- SASS to compile CSS preproccesor, included in SASS minify for less size.
# For script files used:
- Babel to support legacy browsers (by polyfills).
- Uglify.js to minify scripts files.
- Concat plugin to connect files in one.
# Other plugins: 
- Sharp library, that make moder image extentions like webp and avif, compress png and jpg images.
- Plugin for calculate final size of parts.
- Soursemaps plugin, makes .map for compilated files to watch sources.
- Browser-sync for opening local server with hot-reload and many features.
- Del plugin to clean directories before work.
- Htmlmin to minify HTML files.
- File-include to get module functionality in natuve HTML.
- Plugins to transfer fonts from ttf to woff2.
# 
#
# For help write to lavr.marudenko@gmail.com, Skype and telegram @blatisgense.
